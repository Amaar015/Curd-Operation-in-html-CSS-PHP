


<?php 

session_start();

  $name=$_POST['name'];
 $email=$_POST['email'];
   $password=$_POST['password'];

   if($email=="razaammar582@gmail.com" && $password=="42909388"){
?>

<script>
    alert("Login successfull");
</script>
<?php
  $_SESSION['a']=$email;
header("location:profile.php");

   }else{
    
header("location:form.php");
           
   }


?>