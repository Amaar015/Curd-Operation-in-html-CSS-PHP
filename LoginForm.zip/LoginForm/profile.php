
<?php
session_start();

if(isset($_SESSION['a'])){
    
}
else{
    
   header("location:form.php");
}


?>







<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Responsive Navbar</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="nave.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
        integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

</head>

<body>
    <div id="nav">
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <li class="fas fa-bars"></li>
        </label>

        <label class="logo">Pakistan Education</label>
        <ul>
            <li> <a class="active" href="#">|Home</a> </li>
            <li> <a href="#about">|About me</a> </li>
            <li> <a href="#">|Education</a> </li>
            <li> <a href="#">|Contact me</a> </li>
            <li> <a href="logout.php">Logout</a> </li>
        </ul>
        
    </div>
<section>

<?php echo $_SESSION['a']; ?>
</section>

</body>

</html>
