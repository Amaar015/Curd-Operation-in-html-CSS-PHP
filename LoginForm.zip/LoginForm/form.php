
<?php
session_start();

if(isset($_SESSION['a'])){
header("location:profile.php");    

}
else{
    
}


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    
<div class="parent">
<div class="head">
<h1>Login form</h1>
</div>
<div class="form">
    <form action="login.php" method="post">

    <label >Name</label>
    <input id="name" type="text" name="name" placeholder="Username">
    <br><br>
    <label >Email</label>
    <input id="email" type="text" name="email" placeholder="email">
<br><br>
<label >Password</label>
    <input id="pass" type="password" name="password" placeholder="password">

    <br><br>
    <input id="btn" type="submit" name="submit">

    </form>
</div>
</div>

</body>
</html>