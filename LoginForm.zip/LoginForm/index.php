<?php

$server = "localhost";
$username ="root";
$password = "";
$database= "raza";

$conn = mysqli_connect($server, $username, $password, $database);

if(!$conn){
    die("Database Connection failed".mysqli_connect_error($conn));
}

if($_SERVER['REQUEST_METHOD']=="POST"){
    $name =$_POST['name'];
    $cnic =$_POST['cnic'];
    $email =$_POST['email'];
    $password =$_POST['password'];
    $cpassword =$_POST['cpassword'];

    $sql = "INSERT INTO `amaar` (`name`, `cnic`, `email`, `password`, `cpassword`) VALUES ('$name', '$cnic', '$email', '$password', '$cpassword')";

    $result = mysqli_query($conn, $sql);

    if($result){
        echo "Your record is inserted";
    }
    else{
        echo "Your record is not inserter due to ".mysqli_error($conn);
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="form.css">

</head>
<body>

    

    
    <div class="container">
        <div class="header">
            <h2>Create Form</h2>
        </div>
        <form class="form" method="post">
            <div class="form-control ">
                <label for="username" name="username">User Name</label>
                <input id="text" type="text" name="name" placeholder="Name">
                <small> Error Message</small>
            </div>
            <div class="form-control">
                <label for="nic" name="nic">C-NIC</label>
                <input id="text" type="number" name="cnic" placeholder="1234...m">
                <small> Error Message</small>
            </div>
            <div class="form-control">
                <label for="email" name="email">Email</label>
                <input id="textemail" type="email" name="email" placeholder="abc@gmail.com">
                <small> Error Message</small>
            </div>
            <div class="form-control">
                <label for="password" name="password">password</label>
                <input id="textpass" type="password" name="password" placeholder="Password">
                <small> Error Message</small>
            </div>
            <div class="form-control">
                <label for="cpassword" name="cpassword">Confirm Password</label>
                <input id="textcpass" type="password" name="cpassword" placeholder="confirm Password">
                <small> Error Message</small>
            </div>
            <div class="form-control">
                <button>Register</button>
            </div>
        </form>
    </div>

    <div class="container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5 mb-3">Delete Record</h2>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="alert">
                            <input type="hidden" name="id" value="<?php echo trim($_GET["id"]); ?>" />
                            <p>Are you sure you want to delete this student record?</p>
                            <p>
                                <input type="submit" value="Yes" class="btn btn-primary">
                                <a href="index.php" class="btn btn-primary">No</a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- <form action="" method="get">
        <input type="text" name="name" >
        <button >Delete</button>
    </form>
    <script src="form vali.js"></script> -->
</body>
</html>\